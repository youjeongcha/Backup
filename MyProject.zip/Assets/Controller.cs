using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Playables;
using Cinemachine;

public class Controller : MonoBehaviour
{
    [Header("Move")]
    [SerializeField] float speed = 0.0f;
    float velocity = 0.0f;
    PlayerInput playerInput = null;
    Rigidbody rigid = null;

    [Header("Animation")]
    [SerializeField] string moveParameter = "velocity";
    Animator anim = null;
    PlayableDirector director = null;

    private void Awake()
    {
        playerInput = GetComponent<PlayerInput>();
        rigid = GetComponent<Rigidbody>();

        anim = GetComponent<Animator>();
        anim.SetFloat(moveParameter, 0.0f);

        director = GetComponent<PlayableDirector>();
        director.played += (obj) =>
        {
            playerInput.enabled = false;
            rigid.velocity = Vector3.zero;
        };
        director.stopped += (obj) => { playerInput.enabled = true; };
    }

    private void FixedUpdate()
    {
        rigid.velocity = transform.forward * velocity * speed;
    }

    public void MoveAction(InputAction.CallbackContext context)
    {
        Vector2 input = context.ReadValue<Vector2>();

        velocity = 0.0f;
        if (0.0f < input.x) velocity = 1.0f;
        else if (0.0f > input.x) velocity = -1.0f;

        anim.SetFloat(moveParameter, velocity);
    }

    public void AttackAction(InputAction.CallbackContext context)
    {
        if (context.started) director.Play();
    }
}